# dbPlay
First commit

Proof of concept project for CSC 471. 

Included:
1. DB connection and query via SQLite and swift libraries
2. CTA API request example
3. CTA API request string builder
4. XML parsing example/tutorial for a unique CTA API request
5. Some testing
